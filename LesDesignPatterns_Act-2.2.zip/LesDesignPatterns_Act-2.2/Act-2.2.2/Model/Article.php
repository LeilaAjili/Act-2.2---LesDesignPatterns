<?php




class Article{

 

public function __construct( )
    {
        
    }

 
//requete d'insertion d'un post
function addPost()
{
    if( isset($_POST) AND !empty($_POST) )
{
    $bdd = new PDO('mysql:host=localhost;dbname=designpattern;charset=utf8', 'root', '');
    $bdd->exec('INSERT INTO post(titre, texte, image, dateSaisie ) VALUES("'.$_POST['title'].'", "'.$_POST['text'].'", "'.$_POST['link'].'", "'.$_POST['dateSaisie'].'")');
    header("Refresh:0; url=index.php");
}
}



//Affichage des posts
function getPosts()
{
    $bdd = new PDO('mysql:host=localhost;dbname=designpattern;charset=utf8', 'root', '');
    $req = ('SELECT * FROM post');

//affichage des enregistrements
$response = $bdd->query($req);

return $response;


}

}

?>
