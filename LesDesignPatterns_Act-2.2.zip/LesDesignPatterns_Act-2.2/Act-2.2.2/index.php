<?php


require ('Model/Article.php');
$article = new Article();
$response = $article->getPosts();

require ('View/article.php');
$article->addPost();


?>