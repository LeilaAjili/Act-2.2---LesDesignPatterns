
<?php
require ('model/Article.php');
require 'View/article.php';

$article = new Article();
$article->getPosts();
$article->addPost();



?>  

