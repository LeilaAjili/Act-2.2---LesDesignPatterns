<?php

require_once('Controller/articleController.php');






accueilPost();







?>