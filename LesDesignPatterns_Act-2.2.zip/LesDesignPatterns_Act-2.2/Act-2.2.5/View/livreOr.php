<html>
<head>

<link rel="stylesheet" href="./style.css" type="text/css">
<meta charset="utf-8" />
</head>

<body>
<form action="./livreOr.php" method="post" >



<fieldset>
 <legend>Ajouter un nouveau commentaire :</legend>

  <input id="id" name="id" type="hidden" value=<?php echo rand();?>>

  

  <label for="title">Auteur :</label>
   <input type="text" name="texte" size="20" 
   maxlength="40" value="Titre" id="texte" />

  <label for="text">Corps du comentaire :</label>
   <textarea name="texte" id="texte" cols="20" >
   </textarea>

  

   <label for="dateSaisie">Date de publication :</label>
   <input id="dateSaisie" name="dateSaisie" type="date" value="2021-10-07">


</fieldset>

 <p>
 <input type="submit" value="Publier" />
 <input type="reset" value="Annuler" />


 </p>



</form>
<br />
 

 <?php  
  
 
 

  while ($donnees = $response->fetch(PDO::FETCH_ASSOC))
{
    echo '<fieldset>';
   // var_dump($donnees);
     
    foreach ($donnees as $key => $field) {

       
       
        if($key == 'auteur')
  
        echo $field.'&nbsp;';

        

        if($key=='texte')

        echo '<p>'.$field.'</p>';

        if($key == 'dateSaisie')
  
        echo $field.'&nbsp;';

       

        

             
    }

    echo  '</fieldset>';

    
}      


?>
</body>
   