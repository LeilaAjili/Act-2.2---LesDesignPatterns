<?php
require_once 'ConnexionBD.php';

class LivreOr{

public function __construct( )
    {
        
    }
//requete d'insertion d'un post
function addComment()
{
    if( isset($_POST) AND !empty($_POST) )
{
    $bdd1 = new ConnexionBD();

    ConnexionBD::connect('livreOr');
    
    $bdd = $bdd1->getConnection();
    var_dump($bdd);
    $bdd->exec('INSERT INTO commentaire(auteur, texte, dateSaisie ) VALUES("'.$_POST['auteur'].'", "'.$_POST['texte'].'", "'.$_POST['dateSaisie'].'")');
    header("Refresh:0; url=livreOr.php");
}
}


//Affichage des posts
function getComments()
{
    $bdd1 = new ConnexionBD(); 
    
    ConnexionBD::connect('livreOr');
    $bdd = $bdd1->getConnection();
   
    $req = ('SELECT * FROM commentaire');

//affichage des enregistrements
$response = $bdd->query($req);

return $response;


}


}

?>

