

<?php

class ConnexionBD

{

    private static $instance = null;

    private static $connection;

    public static function getInstance()

    {

        if (is_null(self::$instance)) {

            self::$instance = new ConnexionBD();

        }

        return self::$instance;

    }

    public function __construct()

    {

     

         //$this->connection =  new mysqli('localhost', 'root', '', $dbName);


    }

    public static function connect($dbName)

    {

        self::$connection = new PDO("mysql:host=localhost; dbname=$dbName", "root", "");

    }

    public static function getConnection()

    {

        return self::$connection;

    }

}


