<?php
require_once 'Model/Article.php';


function accueilPost()
{

    $article = new Article();
    $response = $article->getPosts();
    $article->addPost();
    require 'View/article.php';
}


?>