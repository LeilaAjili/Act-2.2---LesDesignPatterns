<?php
require_once 'Model/LivreOr.php';


function accueilComment()
{

    $comment = new LivreOr();
    $response = $comment->getComments();
    $comment->addComment();
    require 'View/livreOr.php';
}


?>