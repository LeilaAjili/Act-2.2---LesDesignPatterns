<?php

class ConnexionBD {
  // Gardez l'instance de classe.
  private static $instance = null;
  private $conn;
   
  
  private function __construct()
  {
    $this->conn = new PDO("mysql:host=localhost; dbname=designpattern", "root", "");
  }
  
  public static function getInstance()
  {
    if(!self::$instance)
    {
      self::$instance = new ConnexionBD();
    }
   
    return self::$instance;
  }
  
  public function getConnection()
  {
    return $this->conn;
  }
}
?>