<?php
require 'ConnexionBD.php';
class Article{

public function __construct( )
    {
        
    }
//requete d'insertion d'un post
function addPost()
{
    if( isset($_POST) AND !empty($_POST) )
{
    $instance = ConnexionBD::getInstance();
    $bdd = $instance->getConnection();
    $bdd->exec('INSERT INTO post(titre, texte, image, dateSaisie ) VALUES("'.$_POST['title'].'", "'.$_POST['text'].'", "'.$_POST['link'].'", "'.$_POST['dateSaisie'].'")');
    header("Refresh:0; url=index.php");
}
}

//Affichage des posts
function getPosts()
{
    $instance = ConnexionBD::getInstance();
    $bdd = $instance->getConnection();
    $req = ('SELECT * FROM post');

//affichage des enregistrements
$response = $bdd->query($req);

return $response;


}


}

?>
