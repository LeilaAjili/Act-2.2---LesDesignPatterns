<?php

require('Controller/controller.php');

getPosts();

addPost();


?>