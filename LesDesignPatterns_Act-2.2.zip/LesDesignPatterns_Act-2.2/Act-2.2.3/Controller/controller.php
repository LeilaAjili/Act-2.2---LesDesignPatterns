<?php
require 'Model/Article.php';
function getPosts()
{

    $article = new Article();
    $response = $article->getPosts();
    require 'View/article.php';
}

function addPost()
{
    require_once('View/article.php');
    $article = new Article();
    $article->addPost();
}
