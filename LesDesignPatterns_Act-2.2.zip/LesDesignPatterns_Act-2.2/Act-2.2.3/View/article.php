<html>
<head>

<link rel="stylesheet" href="./style.css" type="text/css">
<meta charset="utf-8" />
</head>

<body>
<form action="index.php" method="post" >



<fieldset>
 <legend>Ajouter un nouveau post :</legend>

  <input id="id" name="id" type="hidden" value=<?php echo rand();?>>

  

  <label for="title">Titre :</label>
   <input type="text" name="title" size="20" 
   maxlength="40" value="Titre" id="title" />

  <label for="text">Corps du post :</label>
   <textarea name="text" id="text" cols="20" >
   </textarea>

   <label for="link">Lien image :</label>
   <input type="text" name="link" size="20" 
   maxlength="40" value="" id="link" />

   <label for="dateSaisie">Date de publication :</label>
   <input id="dateSaisie" name="dateSaisie" type="date" value="2021-10-07">


</fieldset>

 <p>
 <input type="submit" value="Publier" />
 <input type="reset" value="Annuler" />
 </p>

</form>
<br />
 <table>
    
   <th>Titre</th>
    <th>Texte</th>
    <th>Date de publication</th>
   
    <th>lien</th>

 <?php  
  
  while ($donnees = $response->fetch(PDO::FETCH_ASSOC))
{
    echo '<tr>';
     
    foreach ($donnees as $key => $field) {

      if($key != 'id')
  
        echo '<td>' . $field . '</td>';
             
    }

    echo '</tr>';
}      
echo '</table>';

?>
</body>
   