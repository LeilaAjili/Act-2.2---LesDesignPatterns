<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>livre d'or</title>
</head>

<body>
    <center>
        <h3>Ecrire dans le livre</h3>
        <form method="post" action="http://localhost/Act-2.2/livre.ind.php">
            <input type="text" name='auteur' placeholder="auteur" style="display: block;margin-top:20px" />
            <textarea type="textarea" name='texte' placeholder="ajouter le texte" style="display: block; margin-top:20px; height:100px; width:170px;"></textarea>
            <input type="submit" value="Ecrire" />
        </form>
    </center>
</body>

</html>